package Java_Assignment;

public class Fibonacci {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
   int n1=0,n2=1,limit=20;
   System.out.println("Fibonacci series from 0 to 20 ");
   System.out.println(n1+"\n"+n2);
   for(int i=2;i<=limit;i++)
   {
	   int n3=n1+n2;
	   System.out.println(n3+"");
	   n1=n2;
	   n2=n3;
   }
   
	}

}
