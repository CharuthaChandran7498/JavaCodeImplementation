package Java_Assignment;
import java.util.*;
public class PrimeNumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
 int n,flag=0;
 System.out.println("Enter a number");
 Scanner sc=new Scanner(System.in);
 n=sc.nextInt();
 for(int i=2;i<=n/2;++i)
 {
	 if(n%i==0)
	 {
		 flag=1;
		 break;
	 }
 }
 if(flag==0)
 {
	 System.out.println("Number is prme");
	 
 }
 else
 {
	 System.out.println("Number is not prime");
 }
 
	}

}
