package Java_Assignment;

import java.util.Scanner;

public class Swapping {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int temp=0;
		Scanner sc=new Scanner(System.in);
       System.out.println("Enter 2 numbers");
       int a=sc.nextInt();
       int b=sc.nextInt();
       System.out.println("Numbers before swapping"+a+" "+b);
       temp=a;
       a=b;
       b=temp;
       System.out.println("Numbers after swapping"+a+" "+b);
       
	}

}
