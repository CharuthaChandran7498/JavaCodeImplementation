package Java_Assignment;

import java.util.Scanner;

public class GetDigits {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
System.out.println("enter string");
Scanner sc=new Scanner(System.in);
String s=sc.nextLine();
System.out.println("Integers are:");
for(char c :s.toCharArray())
{
	if(Character.isDigit(c))
	{
		System.out.println(c+"\t");
	}
}
	}

}
