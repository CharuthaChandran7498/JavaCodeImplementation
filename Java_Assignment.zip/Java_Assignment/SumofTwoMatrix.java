package Java_Assignment;

public class SumofTwoMatrix {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int [][]m1= {{2,3},{7,8}};
int [][]m2= {{5,1},{9,8}};
int r=2,c=2;
int [][]m3=new int[r][c];
for(int i=0;i<r;i++)
{
	for(int j=0;j<c;j++)
	{
		m3[i][j]=m1[i][j]+m2[i][j];
	}
}
System.out.println("Addition of two matrices is");
for(int i=0;i<r;i++)
{
	for(int j=0;j<c;j++)
	{
		System.out.print(m3[i][j]);
		System.out.print("\t");
	}
	System.out.println("\n");
}

	}

}
