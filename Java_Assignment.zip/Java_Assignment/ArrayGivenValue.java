package Java_Assignment;

public class ArrayGivenValue {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int[] a= {5,3,8,9,6};int g=8;
int flag=1;
for(int i :a)
{
	if(i==g)
	{
		flag=0;
		break;
	}
}
if(flag==0)
	System.out.println("Number found");
else
	System.out.println("Number not found");
	

	}

}
