package Java_Assignment;
     import java.util.*;
public class MultiplicationTable {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
     int i,n;
     Scanner sc=new Scanner(System.in);
     System.out.println("Enter the number");
     n=sc.nextInt();
     for(i=1;i<=10;++i)
     {
    	 System.out.println(i+"*"+n+"="+(n*i));
     }
	}

}
