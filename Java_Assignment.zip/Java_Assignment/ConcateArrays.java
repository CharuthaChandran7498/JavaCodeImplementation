package Java_Assignment;

public class ConcateArrays {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int []a1= {1,2,3};
int []a2= {4,5,6};
int l1=a1.length;
int l2=a2.length;
int l3=l1+l2;
int []a3=new int[l3];
for(int i=0;i<l1;i++)
	a3[i]=a1[i];
for(int i=0;i<l2;i++)
	a3[l1+i]=a2[i];
for(int i=0;i<l3;i++)
	System.out.println(a3[i]);

	}

}
