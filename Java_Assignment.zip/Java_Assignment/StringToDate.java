package Java_Assignment;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class StringToDate {

	public static void main(String[] args) throws ParseException {
		// TODO Auto-generated method stub
       String s="07/04/2022";
       Date d=new SimpleDateFormat("DD/MM/YYYY").parse(s);
       System.out.println("The string is:"+s);
       System.out.println("The date is:"+d);
       
	}

}
