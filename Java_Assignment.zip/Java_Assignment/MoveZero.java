package Java_Assignment;

public class MoveZero {

	
static void moveAllZeros(int a[],int n)
{
	int c=0;
	for(int i=0;i<n;i++)
		if(a[i]!=0)
		a[c++]=a[i];
		while(c<n)
		a[c++]=0;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a[]= {1,0,7,8,6,4,0,0};
		int n=a.length;
		moveAllZeros(a,n);
		System.out.println("Array after moving all zeros to back");
		for(int i=0;i<n;i++)
			System.out.println(a[i]+"");
	}

}
