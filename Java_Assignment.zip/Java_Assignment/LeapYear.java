package Java_Assignment;
import java.util.*;
public class LeapYear {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
         int year,flag=0;
         Scanner sc=new Scanner(System.in);
         System.out.println("Enter the year");
         year=sc.nextInt();
         if(year%4==0)
         {
        	 if(year%100==0)
        	 {
        		 if(year%400==0)
        		 {
        			 flag=1;
        		 }
        		 else
        			 System.out.println("Not leap year");
        	 }
        	 else
        		 flag=1;
         }
         else 
        	 System.out.println("Not leap year");
         
         if(flag==1)
         {
        	 System.out.println("It is leap year");
         }
	}

}
