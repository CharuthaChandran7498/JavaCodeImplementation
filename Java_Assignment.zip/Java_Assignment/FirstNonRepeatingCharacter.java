package Java_Assignment;

public class FirstNonRepeatingCharacter {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
String s="Hello world";
boolean flag=false;
for(int i=0;i<s.length();i++)
{
	flag=true;
	char c=s.charAt(i);
	for(int j=0;j<s.length();j++)
	{
		if(c==s.charAt(j) && j!=i)
		{
			flag=false;
			break;
		}
	}
	if(flag)
	{
		System.out.println("The char is"+c);
		break;
	}

		
}
if(!flag)
{
	System.out.println("no single character found");
}
	}

}
