package Java_Assignment;

import java.util.Scanner;

public class CountVowelsConstants {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
      String s;
      int v=0,c=0;
      Scanner sc=new Scanner(System.in);
      System.out.println("Enter a string");
      s=sc.nextLine();
      for(int i=0;i<s.length();i++)
      {
      if((s.charAt(i)=='a' || s.charAt(i)=='i' || s.charAt(i)=='o' || s.charAt(i)=='u' || s.charAt(i)=='e' || s.charAt(i)=='A' || s.charAt(i)=='E' || s.charAt(i)=='I' || s.charAt(i)=='O' || s.charAt(i)=='U'))
      {
    	  v++;
      }
      if(s.charAt(i)>='a' || s.charAt(i)<='z' || s.charAt(i)>='A' || s.charAt(i)<='Z')
      {
    	  c++;
      }
	}
     System.out.println("Vowels in the sentance are:"+v);
     System.out.println("Constants in the sentance are:"+c);
     
	}
}
