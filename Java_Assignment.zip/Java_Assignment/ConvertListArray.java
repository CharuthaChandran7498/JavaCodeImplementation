package Java_Assignment;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class ConvertListArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<String> l1=new LinkedList<String>();
		l1.add("one");
		l1.add("two");
		l1.add("three");
		String[] l1Array=l1.toArray(new String[0]);
		System.out.println("List to Array");
		for(int j=0;j<l1Array.length;j++)
		{
			System.out.println(l1Array[j]);
		}
	}

}
