package Java_Assignment;
import java.util.*;
import java.util.ArrayList.*;
public class JoinList {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
List<Integer> l1=new ArrayList<Integer>();
l1.add(1);
l1.add(2);
l1.add(3);
List<Integer> l2=new ArrayList<Integer>();
l2.add(4);
l2.add(5);
List jl=new ArrayList<Integer>();
jl.addAll(l1);
jl.addAll(l2);
System.out.println(jl);

}

}
