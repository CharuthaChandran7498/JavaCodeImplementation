package Java_Assignment;

public class LargestElementArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
    int a[]= {9,7,3,1,10};
    int large=a[0];
    for(int i=0;i<a.length;i++)
    {
    	if(a[i]>large)
    	{
    		large=a[i];
    		
    	}
    	
    }
    System.out.println("Largest of array is"+large);
	}

}
