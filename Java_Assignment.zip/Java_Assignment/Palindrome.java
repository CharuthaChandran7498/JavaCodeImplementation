package Java_Assignment;

import java.util.Scanner;

public class Palindrome {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
String s,r="";
int l;
System.out.println("Enter string");
Scanner sc =new Scanner(System.in);
s=sc.nextLine();
l=s.length();
for(int i=l-1;i>=0;i--)
{
	r=r+s.charAt(i);
}
if(s.equals(r))
{
	System.out.println("String is palindrome");
}
else
	System.out.println("String is not palindrome");

	}

}
