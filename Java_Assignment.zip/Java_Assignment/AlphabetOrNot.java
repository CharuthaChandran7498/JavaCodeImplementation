package Java_Assignment;
import java.util.*;
public class AlphabetOrNot {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
       Scanner sc=new Scanner(System.in);
       System.out.println("Enter the character");
       char s=sc.next().charAt(0);
       if((s>='A' && s<='Z') || (s>='a' && s<='z'))
       {
    	   System.out.println("It is an alphabet");
       }
       else
    	   
    	   System.out.println("It is not an alphabet");
	}

}
