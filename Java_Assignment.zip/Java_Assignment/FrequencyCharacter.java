package Java_Assignment;

public class FrequencyCharacter {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
String s="Hello world";
int[] freq=new int[s.length()];
char string1[]=s.toCharArray();
for(int i=0;i<s.length();i++)
{
	freq[i]=1;
	for(int j=i+1;j<s.length();j++)
	{
		if(string1[i]==string1[j])
		{
			freq[i]++;
			string1[j]='0';
			
		}
	}
}
System.out.println("characters and their frequencies");
for(int i=0;i<freq.length;i++)
{
	if(string1[i] !=  ' ' && string1[i]!='0')
	System.out.println(string1[i]+"_"+freq[i]);
}
	}

}
