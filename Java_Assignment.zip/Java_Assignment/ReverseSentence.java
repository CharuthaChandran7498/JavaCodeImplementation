package Java_Assignment;

public class ReverseSentence {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
  String s="This is java";
  String r=reverse(s);
  System.out.println("The reverse sentance is: "+r);
  
	}

	private static String reverse(String s) {
		// TODO Auto-generated method stub
		if(s.isEmpty())
          return s;
		return reverse(s.substring(1))+s.charAt(0);
	}

	
}
