package Java_Assignment;

public class Average_Array {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int a[]= {5,3,4,6,7,8},sum=0,avg;
for(int i=0;i<a.length;i++)
{
	sum=sum+a[i];
}
avg=sum/a.length;
System.out.println("Avg of array is"+avg);
	}

}
