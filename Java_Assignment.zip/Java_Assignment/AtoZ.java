package Java_Assignment;

public class AtoZ {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
       for(char i='A';i<='Z';i++)
       {
    	   System.out.println(i);
       }
	}

}
