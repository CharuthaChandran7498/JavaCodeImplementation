package Java_Assignment;
import java.util.*;
public class DuplicateChar {

	static void remov(char s[],int length)
	{
		int in=0;
		for(int i=0;i<length;i++)
		{
			int j;
		for(j=0;j<i;j++)
		{
			if(s[i]==s[j])
			{
				break;
			}
		}
		if(j==i)
		{
			s[in++]=s[i];
		}
		}
		System.out.println(String.valueOf(Arrays.copyOf(s, in)));
	}



	public static void main(String[] args) {
		// TODO Auto-generated method stub
String s1="Hello world";
char s[]=s1.toCharArray();
int length=s.length;
remov(s,length);
	}

}

