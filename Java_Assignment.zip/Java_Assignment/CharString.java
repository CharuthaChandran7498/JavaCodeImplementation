package Java_Assignment;

public class CharString {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
       char c='A';
       String s1="Hiii";
       String s=Character.toString(c);
       System.out.println("the string is:"+s);
       char c1=s1.charAt(0);
       System.out.println("the 1 st character s:"+c1);
	}

	

}
