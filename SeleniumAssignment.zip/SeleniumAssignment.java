package SeleniumImplement;

import java.awt.Desktop.Action;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class SeleniumAssignment {
	public static WebDriver driver=null;
	public static Actions action=null;
	     @BeforeTest
	public void setup()
	{
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\CHARCHAN\\Downloads\\chromedriver_win32//chromedriver.exe");

		//Creating an object of ChromeDriver
		 driver = new ChromeDriver();
		
	}
    @Test(priority=0)
    public void login() throws Exception
    {   try
          {
    	driver.get("http://automationpractice.com/index.php");
		driver.manage().window().maximize();
		driver.findElement(By.className("login")).click();
		driver.findElement(By.id("email")).sendKeys("charutha@gmail.com");
		driver.findElement(By.id("passwd")).sendKeys("Charutha123@");
		driver.findElement(By.id("SubmitLogin")).click();
          }
    catch(Exception e)
    {
    	System.out.println("Exception");
    	e.printStackTrace();
    }
    }
    @Test(priority=1)
    public void selectTshirt() throws Exception
    {    
    	try
    	{
    	 action=new Actions(driver);
    	WebElement women=driver.findElement(By.xpath("//a[@title='Women']"));
    	action.moveToElement(women).build().perform();
    	driver.findElement(By.xpath("//a[@title='T-shirts']")).click();
    	WebElement element=driver.findElement(By.xpath("//img[@title='Faded Short Sleeve T-shirts']"));
    	action.moveToElement(element).build().perform();
    	Thread.sleep(2000);
    	
    	}
    	catch(Exception e)
    	{
    		System.out.println("Exception");
    		e.printStackTrace();
    	}
    	
    }
    @Test(priority=2)
    public void clickMore() throws Exception
    {  
    	try
    	{
    		driver.findElement(By.xpath("//span[text()='More']")).click();
    		Thread.sleep(2000);
    		
    	}
    	catch(Exception e)
    	{
    		System.out.println("Exception");
    		e.printStackTrace();
    	}
    }
    @Test(priority=3)
    public void setProductDetails()
    {
    	try
    	{
    		    Thread.sleep(2000); 
                WebElement quantity=driver.findElement(By.id("quantity_wanted"));
                quantity.clear();
                quantity.sendKeys("2");
                Select size= new Select(driver.findElement(By.id("group_1")));
        		size.selectByIndex(2);
        		driver.findElement(By.id("color_14")).click();
        		
    	}
    	catch(Exception e)
    	{
    		System.out.println("Exception");
    		e.printStackTrace();
    		
    	}
    	
    }
    @Test(priority=4)
    public void addToCartAndCheckout() throws InterruptedException
    {
    	try
    	{
    	driver.findElement(By.id("add_to_cart")).click();
    	driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
    	driver.findElement(By.xpath("//a[@title='Proceed to checkout']")).click();
    	
        
    }
    	catch(Exception e)
    	{
    		System.out.println("Exception");
    		e.printStackTrace();
    	}
    }

    
  @AfterTest
    
	public void end()
	{
    	driver.close();
	}
   
	

}
